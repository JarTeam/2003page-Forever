Uhh yeah, this is the xpuser index
